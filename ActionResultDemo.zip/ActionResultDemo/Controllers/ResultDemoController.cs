﻿using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace ActionResultDemo.Controllers
{
    public class ResultDemoController : Controller
    {
        // 1. ViewResult
        public IActionResult Home()
        {
            return View("HomeView");
        }

        // 2. JsonResult
        public JsonResult GetUserInfo()
        {
            var user = new { Username = "Alice", Age = 25 };
            return Json(user);
        }

        // 3. ContentResult
        public ContentResult ShowMessage()
        {
            return Content("This is a simple content result.");
        }

        // 4. FileResult
        public FileResult DownloadDocument()
        {
            byte[] fileBytes = System.IO.File.ReadAllBytes("files/sample.docx");
            return File(fileBytes, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "sample.docx");
        }

        // 5. RedirectResult
        public RedirectResult RedirectToExternalSite()
        {
            return Redirect("https://www.google.com");
        }

        // 6. RedirectToActionResult
        public RedirectToActionResult GoToDashboard()
        {
            return RedirectToAction("Dashboard", "User");
        }

        // 7. RedirectToRouteResult
        public RedirectToRouteResult RedirectToCustomRoute()
        {
            return RedirectToRoute(new { controller = "Profile", action = "Details", id = 5 });
        }

        // 8. StatusCodeResult
        public StatusCodeResult ReturnNotFound()
        {
            return StatusCode(404); // Not Found
        }

        // 9. EmptyResult
        public EmptyResult ExecuteSilently()
        {
            // Perform some operations
            return new EmptyResult();
        }

        // 10. PartialViewResult
        public PartialViewResult LoadPartial()
        {
            return PartialView("_PartialDetails");
        }

        // 11. ObjectResult
        public ObjectResult FetchData()
        {
            var product = new { Id = 1, Name = "Laptop", Price = 999.99 };
            return new ObjectResult(product) { StatusCode = 200 };
        }
    }
}
